import sensor, image, time, math
import lcd
import pyb, ustruct
from machine import I2C
from vl53l1x import VL53L1X
from pyb import UART
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA) # we run out of memory if the resolution is much bigger...
sensor.skip_frames(30)
sensor.set_auto_gain(False)  # must turn this off to prevent image washout...
sensor.set_auto_whitebal(False)  # must turn this off to prevent image washout...
sensor.set_vflip(True)
sensor.set_hmirror(True)
text_cloud='u'
###########################################################################################
#I2C初始化

i2c = I2C(2)#I2C2是用于激光测距的


bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)
bus.deinit() # 重启I2C
bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)


clock = time.clock()
uart_A = UART(1, 9600)
shape=(43, 0, 58, 10, -23, 74)#色块阈值
ration=(71, 100, 12, 127, -128, 27)#激光色块外阈值
ration1=(47, 27, 38, 127, -112, 127)#激光色块内阈值
#lcd.init()
def find_max(blobs):
    max_size =0
    for blob in blobs:
        if blob[2]*blob[3]>max_size:
            max_blob=blob
            max_size = blob[2]*blob[3]
    return max_blob
#################此处函数是检测激光是否打到正中心，并且发送串口######################################
def data_send(text):
    data = ustruct.pack("<%ds" % len(text), text)
    try:
        bus.send(ustruct.pack("<h", len(data)), timeout=100) # Send the len first (16-bits).
        try:
            bus.send(data, timeout=100)
            print("Sent Data!")
        except OSError as err:
            pass
    except OSError as err:
        pass



################### I2C发送数据给从设备#########################################################
def clod_plant(jx,jy,blobx,bloby):
#定义发送字符
    text_cloud="o"
    if jx in range(blobx-4,blobx+4):
        if jy in range(bloby-4,bloby+4):
            print()
            text_cloud="o"
        if jy < bloby-4:
            text_cloud="d"
            #uart_B.write('d')
            #data_send(textd)
            #pyb.delay(10)
        if jy > bloby+4:
            #jy > bloby+1
            text_cloud="u"
            #uart_B.write('u')
            #data_send(textu)
            #pyb.delay(10)
            #print("u")
    if jx < blobx-4:
        text_cloud="r"

        #uart_B.write('r')
        #data_send(textr)
        #pyb.delay(20)
    if jx > blobx+4:
        text_cloud="l"

        #uart_B.write('l')
        #data_send(textl)
        #pyb.delay(10)
    return text_cloud
###################################################################################################
###################################################################################################
#######################################激光测距#####################################################
#######################################激光测距#####################################################
def distance_sensor(i2c):
    distance = VL53L1X(i2c)
    print("range: mm ", distance.read())
    return distance.read()





###################################################################################################
#形状识别函数、此函数必须放在色块区域内
def shape_detect(roi,img,circle_int,rec_int,three_int):
    roi1=[roi[0]-50,roi[1]-50,roi[2]+100,roi[3]+100]
    circles=img.find_circles(roi=roi1, threshold = 3500, x_margin = 10, y_margin = 10, r_margin = 10,r_min = 2, r_max = 100, r_step = 2)
    rec=img.find_rects(roi)
    if len(circles)>0:
        circle_int=1
        print("圆形")
        shape='c'
    if len(rec)>0:
        rec_int=1
        print("正方形")
        shape='s'
    if circle_int|rec_int==0:
        three_int=1
        print("正三角形")
        shape='t'
    return shape

for i in range (10) :
    circle_int=0
    rec_int =0
    three_int=0
    length = 100
    clock.tick()
    distance1=distance_sensor(i2c)
    #distance1=0
    img = sensor.snapshot()
    all_blobs = img.find_blobs([shape],merge=True)

    
    #lcd.display(img)
    if all_blobs is not None:
        #max_blob=find_max(all_blobs)
        max_blob = find_max(all_blobs)
        shape1=shape_detect(max_blob.rect(),img,circle_int,rec_int,three_int)#检测出色块的形状
        img.draw_rectangle(max_blob.rect(),color=(255,0,0))
        img.draw_cross(max_blob.cx(),max_blob.cy(),color=(0,255,0))
        cx=max_blob.cx()
        cy=max_blob.cy()
        rect_1=max_blob.rect()


while(text_cloud!='o'):
    img = sensor.snapshot()
    jiguang = img.find_blobs([ration],merge=True)
    img.draw_rectangle(rect_1,color=(255,0,0))
    img.draw_cross(cx,cy,color=(0,255,0))
    if jiguang:
        for jiguangs in jiguang:
            img.draw_rectangle(jiguangs.rect(),color=(0,255,0))
            img.draw_cross(jiguangs.cx(),jiguangs.cy(),color=(255,0,0))
            ax =jiguangs.cx()
            by =jiguangs.cy()
            text_cloud=clod_plant(ax,by,cx,cy)
            bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)
            bus.deinit() # Fully reset I2C device...
            bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)
            buf=text_cloud+shape1+str(length)+str(distance1)+"\n"
            print(buf)
            text_all=buf
            data_send(text_cloud)


            #text_cloud=clod_plant(ax,by,cx,cy)
            print(distance1)
            #img.draw_string(x, y, "Hello World!", color = (255, 0, 0), scale = 2, mono_space = False,
                                   #char_rotation = 0, char_hmirror = False, char_vflip = False,
                                   #string_rotation = 0, string_hmirror = False, string_vflip = False)
    else:

        jiguang1 = img.find_blobs([ration1],merge=True)
        for jiguangs1 in jiguang1:
            img.draw_rectangle(jiguangs1.rect(),color=(0,255,0))
            img.draw_cross(jiguangs1.cx(),jiguangs1.cy(),color=(255,0,0))
            ax =jiguangs1.cx()
            by =jiguangs1.cy()

            print(distance1)

            text_cloud=clod_plant(ax,by,cx,cy)
            bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)
            bus.deinit() # Fully reset I2C device...
            bus = pyb.I2C(4, pyb.I2C.SLAVE, addr=0x12)
            buf=text_cloud+shape1+str(length)+str(distance1)+"\n"
            print(buf)
            text_all=buf
            data_send(text_cloud)

    #lcd.display(img)
for i in range(10):
    data_send(text_cloud)
for i in range(10):
    text_cloud='a'
    buf=text_cloud+shape1+str(length)+str(distance1)+"\n"
    data_send(buf)
